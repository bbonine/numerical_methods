//quad_3.h

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Part II: Make the quadratic solver a subroutine
in a separate file. This is the header, where
in theory we will instantiate the function.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

double quad_root_1(double,double,double);

double quad_root_2(double,double,double);


// Now include roots from in class method
double quad_root_3(double,double);
